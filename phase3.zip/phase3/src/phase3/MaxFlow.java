package phase3;

import java.io.*;
import java.lang.*;
import java.util.*;
import java.util.LinkedList;

class MaxFlow {

    // Returns true if there is a path from source 's' to sink 't' in residual graph.
    static boolean bfs(int rGraph[][], int s, int t, int parent[]) {
        // Create a visited array and mark all vertices as not visited
        boolean visited[] = new boolean[6];
        for (int i = 0; i < 6; ++i) {
            visited[i] = false;
        }

        LinkedList<Integer> queue = new LinkedList<Integer>();
        //add the source to the queue
        queue.add(s);
        visited[s] = true;
        // the parent of the source is -1
        parent[s] = -1;
        // Standard BFS Loop
        while (queue.size() != 0) {
            // dequeu the queue elements
            int u = queue.poll();
            for (int v = 0; v < 6; v++) {
                //  check if there exist a path between u and v , and v is not visited yet , and the value is greater than zero
                if (visited[v] == false && rGraph[u][v] > 0) {
                    // if we get to the sink the path is true
                    if (v == t) {
                        parent[v] = u;
                        return true;
                    }
                    // add v to the queue
                    queue.add(v);
                    parent[v] = u;
                    // mark as visited
                    visited[v] = true;

                }
            }
        }

        //return false because We didn't reach sink 
        return false;
    }

    // fordFulkerson algorithm Returns tne maximum flow from s to t in the given
    int fordFulkerson(int graph[][], int s, int t) {

        // pointers to the nodes of the graph
        int u, v;

        /* rGraph is the graph we will make changes on it insted of the original graph , [i][j] indicates 
        capacity of edge from i to j (if there is an edge. 
        If rGraph[i][j] is 0, then there is not) */
        int rGraph[][] = new int[6][6];
        for (u = 0; u < 6; u++) {
            for (v = 0; v < 6; v++) {
                rGraph[u][v] = graph[u][v];
            }
        }

        // This array is filled by BFS and to store path
        int parent[] = new int[6];
        // initially flow is 0 
        int max_flow = 0;

        // Augment the flow while there is path from source to sink
        while (bfs(rGraph, s, t, parent)) {

            //LinkedList to store the augmenting path then print it
            LinkedList<Integer> printPath = new LinkedList<Integer>();

            // find the maximum flow through the path found.
            int path_flow = Integer.MAX_VALUE;

            for (v = t; v != s; v = parent[v]) {
                //add the sink to the printPath linked list
                printPath.add(v);

                u = parent[v];

                //path flow is the smallest capacity value of the path
                path_flow = Math.min(path_flow, rGraph[u][v]);

            }
            //add the path
            printPath.add(s);
            Collections.reverse(printPath);

            // update residual capacities of the edges and reverse edges along the path
            for (v = t; v != s; v = parent[v]) {
                u = parent[v];
                //Subtract the path flow from the path
                rGraph[u][v] -= path_flow;
                //update
                rGraph[v][u] += path_flow;

            }

            //print the augmenting path
            for (int i = 0; i < printPath.size(); i++) {
                if ((printPath.get(i) + 1) == 6) {
                    System.out.print(printPath.get(i) + 1);
                } else {
                    System.out.print((printPath.get(i) + 1) + "-->");
                }
            }

            System.out.println("  Path Flow: " + path_flow);
            // Add path flow to max flow to get the overall flow
            max_flow += path_flow;
            System.out.println("Updated Flow: " + max_flow + "\n");

        }
        System.out.println("------------------------------");
        
        System.out.println("\nThe min-cut is: " + max_flow);
        // print min-cut edges
        boolean[] isVisited = new boolean[graph.length];
        dfs(rGraph, s, isVisited);
        // Print all edges that are from a reachable vertex to non-reachable vertex in the original graph 
        System.out.println("The min-cut edges are: ");
        for (int i = 0; i < graph.length; i++) {
            for (int j = 0; j < graph.length; j++) {
                if (graph[i][j] > 0 && isVisited[i] && !isVisited[j]) {
                    j += 1;
                    System.out.println(i + 1 + " --> " + j);

                }
            }
        }
        System.out.println("\n------------------------------");
        // Return the overall flow
        return max_flow;
    }

    // dfs is used to find the min cut
    private static void dfs(int[][] rGraph, int s, boolean[] visited) {
        visited[s] = true;
        for (int i = 0; i < rGraph.length; i++) {
            if (rGraph[s][i] > 0 && !visited[i]) {
                dfs(rGraph, i, visited);
            }
        }
    }

}

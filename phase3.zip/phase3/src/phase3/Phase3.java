//https://www.geeksforgeeks.org/ford-fulkerson-algorithm-for-maximum-flow-problem/
package phase3;

import java.io.*;
import java.lang.*;
import java.util.*;
import java.util.LinkedList;

public class Phase3 {

    public static void main(String[] args) throws java.lang.Exception {
        // Let us create a graph shown in the above example
        int graph[][] = new int[][]{
            {0, 2, 7, 0, 0, 0},
            {0, 0, 0, 3, 4, 0},
            {0, 0, 0, 4, 2, 0},
            {0, 0, 0, 0, 0, 1},
            {0, 0, 0, 0, 0, 5},
            {0, 0, 0, 0, 0, 0}
        };
        MaxFlow m = new MaxFlow();

        System.out.println("---the maximum flow based on Edmonds-Karp algorithm ---");
        System.out.println("*******************************************************\n");
        System.out.println("The maximum flow is: " + m.fordFulkerson(graph, 0, 5));

    }

}
